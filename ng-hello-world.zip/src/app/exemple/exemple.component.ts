import { Component } from '@angular/core';

@Component({
  selector: 'app-exemple',
  template: `
    <p>
      exemple works!
    </p>
  `,
  styles: [
  ]
})
export class ExempleComponent {

}
